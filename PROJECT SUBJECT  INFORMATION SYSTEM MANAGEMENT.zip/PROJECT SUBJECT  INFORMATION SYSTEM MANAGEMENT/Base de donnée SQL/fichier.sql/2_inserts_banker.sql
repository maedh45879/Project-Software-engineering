INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences)  
VALUES ('B001', 'Alice', 'Smith', '1234567890', 'alice.smith@example.com', 5);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B002', 'Bob', 'Johnson', '1234567891', 'bob.johnson@example.com', 8);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B003', 'Charlie', 'Brown', '1234567892', 'charlie.brown@example.com', 10);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B004', 'Diana', 'Williams', '1234567893', 'diana.williams@example.com', 3);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B005', 'Eve', 'Jones', '1234567894', 'eve.jones@example.com', 7);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B006', 'Frank', 'Garcia', '1234567895', 'frank.garcia@example.com', 12);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B007', 'Grace', 'Martinez', '1234567896', 'grace.martinez@example.com', 6);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B008', 'Henry', 'Hernandez', '1234567897', 'henry.hernandez@example.com', 4);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B009', 'Isabella', 'Lopez', '1234567898', 'isabella.lopez@example.com', 9);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B010', 'Jack', 'Gonzalez', '1234567899', 'jack.gonzalez@example.com', 15);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B011', 'Karen', 'Wilson', '1234567800', 'karen.wilson@example.com', 11);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B012', 'Leo', 'Anderson', '1234567801', 'leo.anderson@example.com', 2);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B013', 'Maria', 'Thomas', '1234567802', 'maria.thomas@example.com', 20);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B014', 'Nathan', 'Taylor', '1234567803', 'nathan.taylor@example.com', 18);

INSERT INTO Banker (Banker_id, Name, Surname, Phone, Mail, Years_of_Experiences) 
VALUES ('B015', 'Olivia', 'Moore', '1234567804', 'olivia.moore@example.com', 1);
